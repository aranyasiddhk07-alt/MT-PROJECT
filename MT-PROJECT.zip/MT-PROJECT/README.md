# MT PROJECT — 3D Printed Handheld Fan

Manufacturing Technology project: design and additive manufacture (FDM) of a
**hand-cranked, gear-driven handheld fan** with no motor or battery. A crank
turns a large spur gear that meshes with a small pinion on the propeller shaft,
so the propeller spins several times faster than the crank.

![Exploded view](images/exploded-view-front.jpg)

## Repository contents

| Path | Description |
|------|-------------|
| `cad/fan_A.1.igs` | Full CAD assembly in IGES format (exported from 3DEXPERIENCE / CATIA V6R2026x, units: mm) |
| `docs/Manufacturing_Technology_Project_Report_3D_Printed_Handheld_Fan.pdf` | Project report (10 pages) |
| `docs/Handheld_3D_Printed_Fan.pptx` | Presentation slides |
| `images/` | Exploded-view renders and the process slide |

## Components

| Component | Function | Qty |
|-----------|----------|-----|
| Shell half (front, with pin bosses) | Holds the gear train and forms the grip | 1 |
| Shell half (back, with locating pins) | Closes the body and aligns the halves | 1 |
| Crank handle | Input; converts hand motion to rotation | 1 |
| Large spur gear | First stage of the speed-up | 1 |
| Pinion and propeller shaft | Second stage; carries the propeller | 1 |
| Propeller | Produces the airflow | 1 |
| Propeller cap | Retains the propeller on the shaft | 1 |
| Axle pins | Support the gear and crank shaft inside the body | 2–3 |

## CAD model to finished product

1. **Designing a CAD model** – parts modelled and checked for fit
2. **STL export** – mesh checked and oriented for printing
3. **Slicing** – layer height, infill and supports set
4. **FDM printing** – parts printed in the chosen filament
5. **Finishing** – supports removed, edges sanded and blades balanced
6. **Assembly & test**

![Process](images/cad-to-product-process.jpg)

## Opening the CAD file

`fan_A.1.igs` is a neutral IGES file and opens in CATIA/3DEXPERIENCE,
SolidWorks, Fusion 360, FreeCAD, Onshape and most other CAD tools. To print,
import it, export each part as STL, and slice it.
